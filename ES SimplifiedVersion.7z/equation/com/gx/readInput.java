package com.gx;
import java.util.Scanner;

public class readInput {
    public static String rInput() {
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }
}
